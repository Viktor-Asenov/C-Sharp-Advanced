﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace SoftUniParking
{
    public class Parking
    {
        private HashSet<Car> cars;
        private int capacity;

        public Parking (int capacity)
        {
            this.Cars = new HashSet<Car>(new CarRegistrationNumberComparer());
            this.Capacity = capacity;
        }

        public HashSet<Car> Cars 
        { 
            get { return this.cars; }
            private set { this.cars = value; }            
        }
        
        public int Capacity 
        { 
            get { return this.capacity; }
            private set { this.capacity = value; }            
        }

        public int Count
        {
            get { return this.Cars.Count; }
        }

        private class CarRegistrationNumberComparer : IEqualityComparer<Car>
        {
            public bool Equals(Car x, Car y)
            {
                return x.RegistrationNumber.Equals(y.RegistrationNumber, StringComparison.InvariantCultureIgnoreCase);
            }

            public int GetHashCode(Car obj)
            {
                return obj.RegistrationNumber.GetHashCode();
            }
        }

        public string AddCar(Car car)
        {
            if (this.Cars.Contains(car))
            {
                return "Car with that registration number, already exists!";
            }

            if (this.Cars.Count >= this.Capacity )
            {
                return "Parking is full";
            }
            else
            {
                this.Cars.Add(car);
                return $"Successfully added new car {car.Make} {car.RegistrationNumber}";
            }
        }

        public string RemoveCar(string registrationNumber)
        {
            Car car = this.Cars.FirstOrDefault(c => c.RegistrationNumber == registrationNumber);

            if (car.RegistrationNumber != null)
            {
                this.Cars.Remove(car);
                return $"Successfully removed {registrationNumber}";
            }
            else
            {
                return "Car with that registration number, doesn't exist!";
            }
        }

        public Car GetCar(string registrationNumber)
        {
            return this.Cars.First(c => c.RegistrationNumber == registrationNumber);
        }

        public void RemoveSetOfRegistrationNumber(List<string> registrationnumbers)
        {
            foreach (var registrationNumber in registrationnumbers)
            {
                Car car = this.Cars.FirstOrDefault(c => c.RegistrationNumber == registrationNumber);

                if (car.RegistrationNumber != null)
                {
                    Cars.Remove(car);
                }
            }
        }
    }
}
